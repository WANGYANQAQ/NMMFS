function [ L ] = Neighbor_Laplace( X,p,deta )
%��������p�����������˹����Laplacian

n=size(X,1);
Dis=zeros(n);
Similar=zeros(n);

for i=1:n
    for j=i+1:n
        Dis(i,j)=norm( X(i,:)-X(j,:) ,2);
         Dis(j,i)=Dis(i,j);
    end
    d=Dis(i,:);
     [value,position]=sort(d);
     neighbood=position(1:p+1);
    for h=2:p+1
           H=neighbood(h);
           ee=Dis(i,H)^2;
           Similar(i,H)=exp(-ee/deta^2);
    end
end

    D = diag(Similar*ones(n,1));
    L=D-Similar;
    

end


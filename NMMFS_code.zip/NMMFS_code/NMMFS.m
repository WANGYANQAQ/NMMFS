function [ W,obj_old ] = NMMFS ( X,Y,ee,gamma,k,alpha,beta,p,deta,mm,alphaw,alphav,alphab,yita )
%  Multi-label feature selection via nonlinear mapping and manifold regularization(NMMFS)
Y = Y';
[n,d] = size(X);
c = size(Y,2);
[ Laplacian ] = Neighbor_Laplace( X,p,deta );
W= ones(d,k);
V=rand(n,k);
B= rand(k,c);

obj_old = [];
maxIter = 500;

for i=1:maxIter
    if i==1
        WW = W*W';
        DD = diag(diag(WW),0)+diag(ee*ones(1,size(WW,1)));
        D = diag(ones(size(DD, 1),1)./diag(2*sqrt(DD)));
        I = ones(size(V));
        e = exp(-X*W);
        II = I./(I+e);
        Wgrad = 2*mm*X'*(II.*(I-II).*(II-V))+2*gamma*D*W+2*yita*W;
        gradw = Wgrad;
    else
        WW = W*W';
        DD = diag(diag(WW),0)+diag(ee*ones(1,size(WW,1)));
        D = diag(ones(size(DD, 1),1)./diag(2*sqrt(DD)));
        I = ones(size(V));
        e = exp(-X*W);
        II = I./(I+e);
        gradw_old=Wgrad;
        Wgrad = 2*mm*X'*(II.*(I-II).*(II-V))+2*gamma*D*W+2*yita*W;
        gradw = 0.6*gradw_old+0.4*Wgrad;
    end
    Wnew = W-alphaw*gradw;
    WWnew = Wnew*Wnew';
    DDnew = diag(diag(WWnew),0)+diag(ee*ones(1,size(WWnew,1)));
    Dnew = diag(ones(size(DDnew, 1),1)./diag(2*sqrt(DDnew)));
    Vgrad = 2*(mm*(V-II)+alpha*(V*B-Y)*B')+2*beta*Laplacian*V+2*yita*V;
    gradv = Vgrad;
    Vnew = V-alphav*gradv;
    Bgrad = 2*alpha*V'*(V*B-Y)+2*yita*B;
    gradb = Bgrad;
    Bnew = B-alphab*gradb;
    I = ones(size(V));
    e = exp(-X*Wnew);
    III = I./(I+e);
    Obj =mm* norm((III-Vnew),'fro')^2 + alpha*norm((Y-Vnew*Bnew),'fro')^2 +beta*trace(Vnew'*Laplacian*Vnew)+2*gamma*trace(Wnew'*Dnew*Wnew)+yita*(norm((Bnew),'fro')^2+norm((Vnew),'fro')^2+norm((Wnew),'fro')^2 ) ;   
    obj_old = [obj_old;Obj];
    W=Wnew;
    V=Vnew;
    B=Bnew;
    if i < 5
        continue;
    end
    stopnow = 1;
    for ii=1:3
        stopnow = stopnow & (abs(Obj-obj_old(i-1-ii)) < 1e-4);
    end
    if stopnow
        break;
    end
end
W = Wnew;
 end


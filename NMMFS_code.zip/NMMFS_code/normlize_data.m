function [norm_data]=normlize_data(data)
%%%���ݱ�׼��
[row,col]=size(data);
min_data=min(data(:,1:col-1),[],1);
max_data=max(data(:,1:col-1),[],1);
num = find(max_data-min_data<1e-6);
diffe=max_data-min_data;
norm_data=(data(:,1:col-1)-min_data(ones(1,row),:))./diffe(ones(1,row),:);
if length(num)~=0
    norm_data(:,num)=1;
end
norm_data=[norm_data,data(:,end)];
end


clc;
clear;
 load('data.mat')
X = normlize_data(X');
ee = 0.0001; p=10; 
k=5; alpha=0.5;   beta=0.5; gamma=0.0005;   yita=0.0001;
mm=0.001; deta=10;  alphaw=0.005;      alphav=0.005;     alphab=0.005;
%% Multi-label feature selection via nonlinear mapping and manifold regularization
[ W,obj_old ] = NMMFS( X',Y,ee,gamma,k,alpha,beta,p,deta,mm,alphaw,alphav,alphab,yita);
 





